/**
 * @returns context types Home
 */

export const HomeActionTypes = {
  SET_CURRENT_PLACES: "SET_CURRENT_PLACES",
  SET_NAME_PLACE: "SET_NAME_PLACE",
  REGISTER_USER: "REGISTER_USER"
};
